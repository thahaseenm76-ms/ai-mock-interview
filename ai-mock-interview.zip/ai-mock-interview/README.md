# InterviewAI — AI Mock Interview System

> BCA Final Year Project | AI + NLP + Flask

Practice real interview questions and get instant AI-powered feedback on your answers — scored on relevance, clarity, depth, and confidence.

---

## Features

- 35+ questions across 5 categories (Python, ML/AI, Web Dev, HR, DSA)
- 🎤 Voice input using Web Speech API (speak your answers)
- ⏱ Live timer per question
- AI scoring on 4 dimensions: Relevance, Clarity, Depth, Confidence
- Ideal answer hints after each question
- Session report with line chart, grade distribution, improvement tips
- Works fully offline (no API key needed)

## Tech Stack

| Layer | Tools |
|---|---|
| Backend | Python, Flask |
| AI Evaluator | Rule-based NLP scoring |
| Frontend | HTML, CSS, JavaScript, Chart.js |
| Voice | Web Speech API |

## Project Structure

```
ai-mock-interview/
├── backend/
│   ├── app.py          ← Flask API
│   ├── questions.py    ← Question bank (35+ questions)
│   └── evaluator.py    ← AI scoring engine
├── frontend/
│   ├── index.html      ← Home / category selection
│   ├── interview.html  ← Interview session page
│   └── report.html     ← Final report page
├── requirements.txt
└── README.md
```

## Setup & Run

```bash
pip install -r requirements.txt
python backend/app.py
# Open → http://localhost:5002
```

Works without backend too — open frontend/index.html directly in Chrome for offline mode.

## Author

**Deen** — BCA Final Year, Mohan Babu University
Internship: Doneswari Technologies LLP (AI & ML)
GitHub: github.com/deen4305
