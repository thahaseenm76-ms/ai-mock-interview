from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import random
from questions import QUESTIONS
from evaluator import evaluate_answer, generate_session_report

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

@app.route('/')
def index():
    return send_from_directory('../frontend', 'index.html')

@app.route('/interview')
def interview():
    return send_from_directory('../frontend', 'interview.html')

@app.route('/report')
def report():
    return send_from_directory('../frontend', 'report.html')

@app.route('/api/questions', methods=['GET'])
def get_questions():
    category = request.args.get('category', 'python')
    count = int(request.args.get('count', 5))
    mode = request.args.get('mode', 'practice')

    qs = QUESTIONS.get(category, QUESTIONS['python'])

    if mode == 'mixed':
        all_qs = []
        for cat_qs in QUESTIONS.values():
            all_qs.extend(cat_qs)
        qs = random.sample(all_qs, min(count, len(all_qs)))
    else:
        qs = random.sample(qs, min(count, len(qs)))

    return jsonify({
        "questions": qs,
        "category": category,
        "total": len(qs)
    })

@app.route('/api/evaluate', methods=['POST'])
def evaluate():
    data = request.get_json()
    question_id  = data.get('question_id', '')
    question_text = data.get('question', '')
    user_answer  = data.get('answer', '')
    category     = data.get('category', 'python')

    result = evaluate_answer(question_id, question_text, user_answer, category)
    result['question'] = question_text
    result['question_id'] = question_id
    return jsonify(result)

@app.route('/api/report', methods=['POST'])
def session_report():
    data = request.get_json()
    answers = data.get('answers', [])
    report = generate_session_report(answers)
    return jsonify(report)

@app.route('/api/categories', methods=['GET'])
def get_categories():
    return jsonify({
        "categories": [
            {"id": "python",  "label": "Python",       "icon": "🐍", "count": len(QUESTIONS['python'])},
            {"id": "ml",      "label": "ML & AI",       "icon": "🤖", "count": len(QUESTIONS['ml'])},
            {"id": "webdev",  "label": "Web Dev",       "icon": "🌐", "count": len(QUESTIONS['webdev'])},
            {"id": "hr",      "label": "HR & Behavioural", "icon": "💼", "count": len(QUESTIONS['hr'])},
            {"id": "dsa",     "label": "DSA",           "icon": "📊", "count": len(QUESTIONS['dsa'])},
            {"id": "mixed",   "label": "Mixed (All)",   "icon": "🎯", "count": 35},
        ]
    })

if __name__ == '__main__':
    app.run(debug=True, port=5002)
