import re
from questions import IDEAL_ANSWERS

FILLER_WORDS = ['um', 'uh', 'like', 'you know', 'basically', 'literally', 'actually', 'so yeah', 'i mean', 'kind of', 'sort of']

POSITIVE_SIGNALS = [
    'example', 'for instance', 'such as', 'because', 'therefore', 'however',
    'in addition', 'furthermore', 'specifically', 'for example', 'this means',
    'i used', 'i built', 'i worked', 'in my project', 'during my internship'
]

TECHNICAL_DEPTH = {
    'python': ['mutable', 'immutable', 'reference', 'object', 'class', 'function', 'module', 'library', 'syntax', 'runtime'],
    'ml': ['model', 'training', 'dataset', 'accuracy', 'algorithm', 'features', 'prediction', 'loss', 'gradient', 'epoch'],
    'webdev': ['http', 'api', 'server', 'client', 'request', 'response', 'database', 'route', 'endpoint', 'authentication'],
    'hr': ['team', 'project', 'challenge', 'solution', 'experience', 'skills', 'goal', 'learn', 'contribute', 'growth'],
    'dsa': ['complexity', 'algorithm', 'data structure', 'time', 'space', 'array', 'node', 'pointer', 'recursion', 'iteration'],
}


def evaluate_answer(question_id, question_text, user_answer, category):
    if not user_answer or len(user_answer.strip()) < 10:
        return {
            "overall_score": 0,
            "relevance_score": 0,
            "clarity_score": 0,
            "depth_score": 0,
            "confidence_score": 0,
            "filler_count": 0,
            "word_count": 0,
            "feedback": "No answer provided. Please attempt the question.",
            "strengths": [],
            "improvements": ["Provide a complete answer", "Aim for at least 3-4 sentences"],
            "ideal_answer_hint": IDEAL_ANSWERS.get(question_id, ""),
            "grade": "F",
        }

    answer_lower = user_answer.lower()
    words = user_answer.split()
    word_count = len(words)

    # 1. Relevance score — keyword overlap with ideal answer
    ideal = IDEAL_ANSWERS.get(question_id, "")
    ideal_words = set(re.findall(r'\b\w{4,}\b', ideal.lower()))
    answer_words = set(re.findall(r'\b\w{4,}\b', answer_lower))
    if ideal_words:
        overlap = len(ideal_words & answer_words) / len(ideal_words)
        relevance = min(100, int(overlap * 160))
    else:
        relevance = 50

    # 2. Clarity score — sentence structure, length, punctuation
    sentences = re.split(r'[.!?]+', user_answer)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 5]
    num_sentences = len(sentences)

    if word_count < 20:     clarity = 30
    elif word_count < 50:   clarity = 55
    elif word_count < 100:  clarity = 75
    elif word_count < 200:  clarity = 90
    else:                    clarity = 85

    if num_sentences >= 2: clarity = min(100, clarity + 5)

    # 3. Depth score — technical terms used
    tech_terms = TECHNICAL_DEPTH.get(category, [])
    tech_found = [t for t in tech_terms if t in answer_lower]
    depth = min(100, 30 + len(tech_found) * 10)

    positive_count = sum(1 for p in POSITIVE_SIGNALS if p in answer_lower)
    depth = min(100, depth + positive_count * 5)

    # 4. Confidence score — based on phrasing
    confident_phrases = ['i know', 'i believe', 'the answer is', 'this works by', 'i used', 'i built', 'for example', 'in my project']
    weak_phrases = ["i'm not sure", "i think maybe", "i don't know", "i'm unsure", "not sure", "i guess"]
    confident_count = sum(1 for p in confident_phrases if p in answer_lower)
    weak_count = sum(1 for p in weak_phrases if p in answer_lower)
    confidence = min(100, max(30, 60 + confident_count * 8 - weak_count * 12))

    # 5. Filler words
    filler_count = sum(answer_lower.count(f) for f in FILLER_WORDS)
    if filler_count > 0:
        confidence = max(20, confidence - filler_count * 5)

    # Overall weighted score
    overall = int(
        relevance * 0.35 +
        clarity  * 0.25 +
        depth    * 0.25 +
        confidence * 0.15
    )
    overall = max(0, min(100, overall))

    # Grade
    if overall >= 85:   grade = "A"
    elif overall >= 70: grade = "B"
    elif overall >= 55: grade = "C"
    elif overall >= 40: grade = "D"
    else:               grade = "F"

    # Strengths
    strengths = []
    if relevance >= 60:   strengths.append("Good coverage of key concepts")
    if word_count >= 60:  strengths.append("Well-elaborated answer with sufficient detail")
    if tech_found:        strengths.append(f"Used technical terms correctly: {', '.join(tech_found[:3])}")
    if positive_count >= 2: strengths.append("Included good examples and reasoning")
    if confident_count >= 1: strengths.append("Spoke with confidence and clarity")
    if not strengths:     strengths.append("Made an attempt at the answer")

    # Improvements
    improvements = []
    if relevance < 50:    improvements.append("Include more relevant keywords and concepts from the topic")
    if word_count < 40:   improvements.append("Elaborate more — aim for at least 4-5 sentences")
    if not tech_found:    improvements.append("Use more technical terms specific to the topic")
    if weak_count > 0:    improvements.append("Avoid uncertain phrases like 'I think maybe' — speak confidently")
    if filler_count > 2:  improvements.append(f"Reduce filler words — found {filler_count} instances")
    if positive_count == 0: improvements.append("Include a real example or use case to strengthen your answer")
    if not improvements:  improvements.append("Great answer! Try adding more specific examples next time")

    return {
        "overall_score":    overall,
        "relevance_score":  relevance,
        "clarity_score":    clarity,
        "depth_score":      depth,
        "confidence_score": confidence,
        "filler_count":     filler_count,
        "word_count":       word_count,
        "feedback":         generate_feedback(overall, grade, strengths, improvements),
        "strengths":        strengths[:3],
        "improvements":     improvements[:3],
        "ideal_answer_hint": IDEAL_ANSWERS.get(question_id, ""),
        "grade":            grade,
        "tech_terms_found": tech_found[:5],
    }


def generate_feedback(score, grade, strengths, improvements):
    if score >= 85:
        return f"Excellent answer! Grade {grade} — You demonstrated strong understanding with clear, well-structured response."
    elif score >= 70:
        return f"Good answer! Grade {grade} — Solid understanding shown. A few more technical details would make it perfect."
    elif score >= 55:
        return f"Average answer. Grade {grade} — You covered the basics but need more depth and specific examples."
    elif score >= 40:
        return f"Below average. Grade {grade} — Key concepts are missing. Review the topic and try to use technical terminology."
    else:
        return f"Needs improvement. Grade {grade} — The answer lacks relevance and depth. Study the ideal answer carefully."


def generate_session_report(answers_data):
    if not answers_data:
        return {}

    scores = [a['overall_score'] for a in answers_data]
    avg = int(sum(scores) / len(scores))

    grade_counts = {}
    for a in answers_data:
        g = a.get('grade', 'F')
        grade_counts[g] = grade_counts.get(g, 0) + 1

    weakest = min(answers_data, key=lambda x: x['overall_score'])
    strongest = max(answers_data, key=lambda x: x['overall_score'])

    all_improvements = []
    for a in answers_data:
        all_improvements.extend(a.get('improvements', []))
    top_improvements = list(dict.fromkeys(all_improvements))[:4]

    if avg >= 80:    overall_grade, verdict = 'A', 'Interview Ready 🎉'
    elif avg >= 65:  overall_grade, verdict = 'B', 'Almost Ready — Minor polish needed'
    elif avg >= 50:  overall_grade, verdict = 'C', 'Needs More Practice'
    else:            overall_grade, verdict = 'D', 'Significant Improvement Needed'

    return {
        "average_score":   avg,
        "overall_grade":   overall_grade,
        "verdict":         verdict,
        "total_questions": len(answers_data),
        "grade_counts":    grade_counts,
        "strongest_area":  strongest.get('question', ''),
        "weakest_area":    weakest.get('question', ''),
        "top_improvements": top_improvements,
        "scores":          scores,
    }
